import os
import subprocess

def build_apk():
    print("[*] جاري بناء التطبيق...")
    
    android_code_dir = "Android_Code"
    
    if not os.path.exists(android_code_dir):
        print("[-] مجلد Android_Code غير موجود! تأكد أنك في المجلد الصحيح.")
        return

    os.chdir(android_code_dir)
    
    # استخدام sh لتشغيل gradlew بدل ./gradlew
    print("[*] جاري تشغيل gradlew...")
    result = subprocess.run(["sh", "gradlew", "assembleDebug"], capture_output=True, text=True)
    
    if result.returncode == 0:
        print("\n[🎯] تم بناء التطبيق بنجاح!")
        print("[*] ملف الـ APK موجود في: Android_Code/app/build/outputs/apk/debug/app-debug.apk")
    else:
        print("\n[-] فشل البناء. الخطأ:")
        print(result.stderr[-1000:]) # طباعة آخر جزء من الخطأ
        print(result.stdout[-1000:])

if __name__ == "__main__":
    build_apk()
